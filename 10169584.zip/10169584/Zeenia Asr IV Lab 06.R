list.files()
install.packages("biwavelet")
library(biwavelet)

apple_df <- read.csv("Apple.csv")
ppt_df <- read.csv("Annual-Ave_Precipitation.csv")


colnames(apple_df) <- c("year", "apple")
colnames(ppt_df) <- c("year", "ppt")


df <- merge(apple_df, ppt_df, by = "year")
df <- subset(df, year >= 1985 & year <= 2014)


apple <- data.frame(time = df$year, value = scale(df$apple))
ppt <- data.frame(time = df$year, value = scale(df$ppt))


coh <- wtc(ppt, apple)


plot(coh,
     plot.cb = TRUE,
     plot.phase = TRUE,
     main = "Wavelet Coherence: Precipitation vs Apple Yield (1985–2014)")


garlic_df <- read.csv("Garlic - Sheet1.csv")
ppt_df <- read.csv("Annual-Ave_Precipitation.csv")


colnames(garlic_df) <- c("year", "garlic")
colnames(ppt_df) <- c("year", "ppt")


df <- merge(garlic_df, ppt_df, by = "year")
df <- subset(df, year >= 1985 & year <= 2014)


garlic <- data.frame(time = df$year, value = scale(df$garlic))
ppt <- data.frame(time = df$year, value = scale(df$ppt))


coh <- wtc(ppt, garlic)


plot(coh,
     plot.cb = TRUE,
     plot.phase = TRUE,
     main = "Wavelet Coherence: Precipitation vs Garlic Yield (1985–2014)")


apricot_df <- read.csv("Appricot.csv")
ppt_df <- read.csv("Annual-Ave_Precipitation.csv")


colnames(apricot_df) <- c("year", "apricot")
colnames(ppt_df) <- c("year", "ppt")


df <- merge(apricot_df, ppt_df, by = "year")
df <- subset(df, year >= 1985 & year <= 2014)


apricot <- data.frame(time = df$year, value = scale(df$apricot))
ppt <- data.frame(time = df$year, value = scale(df$ppt))


coh <- wtc(ppt, apricot)


plot(coh,
     plot.cb = TRUE,
     plot.phase = TRUE,
     main = "Wavelet Coherence: Precipitation vs Apricot Yield (1985–2014)")
